
<?php $__env->startSection('content'); ?>

<main class="signup-form">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <?php if(session()->has('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('success')); ?>

                </div>
                <?php endif; ?>
            	<div class="card">
                    <h3 class="card-header text-center">Register User</h3>
                    <div class="card-body">
                    	<form action="<?php echo e(route('register.custom')); ?>" method="POST">
                    		<?php echo csrf_field(); ?>
                    		<div class="form-group mb-3">
                    			<input type="Text" name="name" class="form-control" placeholder="Name" />
                                <?php if($errors->has('name')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                <?php endif; ?>
                    		</div>
                    		<div class="form-group mb-3">
                    			<input type="text" name="email" class="form-control" placeholder="Email" />
                                <?php if($errors->has('email')): ?>
                                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                <?php endif; ?>
                    		</div>
                    		<div class="form-group mb-3">
                    			<input type="password" name="password" class="form-control" placeholder="Password" />
                                <?php if($errors->has('password')): ?>
                                <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                                <?php endif; ?>
                    		</div>
                    		<div class="d-grid mx-auto">
                    			<button type="submit" class="btn btn-dark btn-block">Sign Up</button>
                    		</div>
                    	</form>
                        <br />
                        <div class="text-center">
                            <a href="<?php echo e(route('login')); ?>">Login</a>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\bank\resources\views/auth/registration.blade.php ENDPATH**/ ?>
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Department extends Model
{
    use HasFactory;
    protect $fillable = ['Bank_name','Bank_Branch','Branch_code','Account_number'];
}
